<?php
	//echo $_GET['callback']."(".json_encode(array('a'=>'b')).")";
	//echo json_encode(array('a'=>'b'));
	echo $_GET['name'];
?>